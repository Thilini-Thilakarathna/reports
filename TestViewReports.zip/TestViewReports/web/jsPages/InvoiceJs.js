/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function () {
    
       
    $('#btnPrint').on('click', function () {
        $('#modal1').iziModal('open');
   
    });
    $('#btnPrintReport').on('click', function () {
      printDetails_001();
    });
    function printDetails_001() {

        var xzz = $('#styleCon').html();
        var pageOne = $('#maidiv001').html();

        newWin = window.open("");
        newWin.document.write('<!DOCTYPE html><html><head><title></title>');
        newWin.document.write('<link rel="stylesheet" media="screen,print" href="../assets/css/bootstrapPrint.css" type="text/css" />');
        newWin.document.write('<link rel="stylesheet" media="screen,print" href="../assets/css/NTRLreports.css" type="text/css" />');
        newWin.document.write(xzz);
        newWin.document.write('</head><body>');
        newWin.document.write('<div class="page" style="position: relative;"><div  ">' + pageOne + '</div></div>');
        newWin.document.write('</body></html>');
        newWin.document.close();
        newWin.focus();
        setTimeout(function () {
            newWin.print();
        }, 800);

    }
    
    
    
});